import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const BlogList = () => {
  return (
    <View>
      <Text>BlogList</Text>
    </View>
  )
}

export default BlogList

const styles = StyleSheet.create({})