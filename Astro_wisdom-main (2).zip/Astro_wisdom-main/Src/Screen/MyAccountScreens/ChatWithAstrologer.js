import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const ChatWithAstrologer = () => {
  return (
    <View>
      <Text>ChatWithAstrologer</Text>
    </View>
  )
}

export default ChatWithAstrologer

const styles = StyleSheet.create({})