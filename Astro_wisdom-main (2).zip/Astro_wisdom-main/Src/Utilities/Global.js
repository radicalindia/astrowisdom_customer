module.exports = {
    //STORE_KEY: '',
    //Google_Key: 'https://maps.googleapis.com/maps/api/geocode/json?key=AIzaSyA-QaeuVFLRXQAD9OrlfQXeDfdCLfoqod4',
    // BASE_URL: 'https://horizonera.in/api/activity.php?method=',
    BASE_URL: 'https://astrowisdom.in/api/activity.php?method=',
  };