const Family ={
    Bold:"Poppins-Bold",
    Medium:"Poppins-Medium",
    Regular:"Poppins-Regular",
    SemiBold:"Poppins-SemiBold",
    Light:"Poppins-Light"
}

export default Family;